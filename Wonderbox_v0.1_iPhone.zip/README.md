# Wonderbox MVP

A small playable mobile web prototype.

## Run
Open `index.html` in a browser. For PWA/offline behavior, serve the folder with any local HTTP server, e.g.:

    python -m http.server 8000

Then open http://localhost:8000

## MVP flow
Open Box #1 → drag cloud to flower → tap Mimi → find tree secret → restore world.

This is a product prototype, not yet a native App Store / Google Play binary.
