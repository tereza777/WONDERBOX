# Wonderbox v0.1 — iPhone/PWA build

This folder is ready for static HTTPS hosting.

Fastest deployment:
1. Upload the contents of this folder to any static host (GitHub Pages, Cloudflare Pages, Netlify, etc.).
2. Open the resulting HTTPS URL in Safari on iPhone.
3. Share → Add to Home Screen → Open as Web App.

Included:
- standalone PWA metadata
- portrait orientation
- home-screen icon
- offline service worker
- playable Box #1 prototype

Note: an actual public URL requires publishing these files to a hosting provider.
